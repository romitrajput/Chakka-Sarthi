// Chakka Saarthi — email-backup
// Emails a full data backup (Excel inside a .zip) to the company's business email.
//   • Weekly: started by the database timer (header x-backup-secret), for every company with a business email.
//   • On request: an admin taps "Email backup" in Settings.
// Nothing is sent when nothing changed since the last backup.
// Uses the same Gmail secrets as pin-reset: SMTP_USER, SMTP_PASS (optional SMTP_HOST, SMTP_PORT).
// Deploy with "Verify JWT" turned OFF (this function checks the caller itself).
import { createClient, SupabaseClient } from "jsr:@supabase/supabase-js@2";
import nodemailer from "npm:nodemailer@6.9.16";
import * as XLSX from "npm:xlsx@0.18.5";
import JSZip from "npm:jszip@3.10.1";
import { Buffer } from "node:buffer";

const URL_ = Deno.env.get("SUPABASE_URL")!;
const db = createClient(URL_, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const reply = (body: Record<string, unknown>, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

// Never put Login PIN hashes, push tokens or reset codes in a backup
const HIDDEN: Record<string, string[]> = {
  users: ["mpin_hash", "fcm_token"],
  companies: ["reset_code", "last_backup_hash"],
};

async function fetchAll(table: string, filter: (q: any) => any): Promise<Record<string, unknown>[]> {
  const out: Record<string, unknown>[] = [];
  for (let from = 0; ; from += 1000) {
    const { data, error } = await filter(db.from(table).select("*")).order("id").range(from, from + 999);
    if (error) throw new Error(`${table}: ${error.message}`);
    out.push(...(data ?? []));
    if (!data || data.length < 1000) break;
  }
  const hide = HIDDEN[table] ?? [];
  return out.map((r) => Object.fromEntries(Object.entries(r).filter(([k]) => !hide.includes(k))));
}

async function fetchIn(table: string, column: string, values: string[]) {
  const out: Record<string, unknown>[] = [];
  for (let i = 0; i < values.length; i += 100) {
    out.push(...await fetchAll(table, (q) => q.in(column, values.slice(i, i + 100))));
  }
  return out;
}

async function collect(companyCode: string) {
  const byCompany = (t: string) => fetchAll(t, (q) => q.eq("company_code", companyCode));
  const companies = await byCompany("companies");
  const users = await byCompany("users");
  const vehicles = await byCompany("vehicles");
  const tickets = await byCompany("tickets");
  const ticketIds = tickets.map((t) => String(t.ticket_id));
  const userIds = users.map((u) => String(u.user_id));
  return {
    "Business": companies,
    "Users": users,
    "Vehicles": vehicles,
    "Trips": tickets,
    "Loading": await fetchIn("loading_status", "ticket_id", ticketIds),
    "Unloading": await fetchIn("unloading_status", "ticket_id", ticketIds),
    "Re-assignments": await fetchIn("trip_reassignments", "ticket_id", ticketIds),
    "Notifications": await fetchIn("notifications", "target_user_id", userIds),
  } as Record<string, Record<string, unknown>[]>;
}

async function sha256(text: string) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

function istStamp(d = new Date()) {
  const ist = new Date(d.getTime() + 330 * 60000);
  return ist.toISOString().slice(0, 16).replace("T", " ");
}

async function backupCompany(company: { company_code: string; company_name: string; business_email: string | null; last_backup_hash: string | null; last_backup_at: string | null }) {
  if (!company.business_email) return { skipped: true, reason: "no_email" };
  const data = await collect(company.company_code);
  const hash = await sha256(JSON.stringify(data));
  if (hash === company.last_backup_hash) {
    return { skipped: true, reason: "no_new_data", last_backup_at: company.last_backup_at };
  }

  const wb = XLSX.utils.book_new();
  let rows = 0;
  for (const [sheet, list] of Object.entries(data)) {
    rows += list.length;
    const ws = XLSX.utils.json_to_sheet(list.length ? list : [{ info: "No rows" }]);
    XLSX.utils.book_append_sheet(wb, ws, sheet.slice(0, 31));
  }
  const xlsx = XLSX.write(wb, { type: "array", bookType: "xlsx" }) as ArrayBuffer;
  const safe = (company.company_name || company.company_code).replace(/[^A-Za-z0-9]+/g, "_");
  const day = istStamp().slice(0, 10);
  const zip = new JSZip();
  zip.file(`Backup_${safe}_${day}.xlsx`, new Uint8Array(xlsx));
  const zipBytes = await zip.generateAsync({ type: "uint8array", compression: "DEFLATE" });

  const smtpUser = Deno.env.get("SMTP_USER");
  const smtpPass = Deno.env.get("SMTP_PASS");
  if (!smtpUser || !smtpPass) throw new Error("Email sending is not set up (SMTP_USER / SMTP_PASS secrets)");
  const transport = nodemailer.createTransport({
    host: Deno.env.get("SMTP_HOST") ?? "smtp.gmail.com",
    port: Number(Deno.env.get("SMTP_PORT") ?? 465),
    secure: true,
    auth: { user: smtpUser, pass: smtpPass.replace(/\s+/g, "") },
  });
  await transport.sendMail({
    from: `Chakka Saarthi <${smtpUser}>`,
    to: company.business_email,
    subject: `Chakka Saarthi backup – ${company.company_name} – ${day}`,
    text: `Backup of ${company.company_name} taken on ${istStamp()} (India time).\n` +
      `${Object.keys(data).length} sheets, ${rows} rows. Keep this email; the zip holds an Excel file.\n` +
      `Login PINs and other secrets are never included.`,
    attachments: [{ filename: `Backup_${safe}_${day}.zip`, content: Buffer.from(zipBytes) }],
  });

  const now = new Date().toISOString();
  await db.from("companies").update({ last_backup_hash: hash, last_backup_at: now }).eq("company_code", company.company_code);
  return { skipped: false, sent_to: company.business_email, rows, last_backup_at: now };
}

const COLS = "company_code, company_name, business_email, last_backup_hash, last_backup_at";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    // Weekly timer from the database
    const secret = req.headers.get("x-backup-secret");
    if (secret) {
      const { data: ok } = await db.rpc("cs_check_backup_secret", { p_secret: secret });
      if (ok !== true) return reply({ error: "Not allowed" }, 401);
      const { data: companies } = await db.from("companies").select(COLS).not("business_email", "is", null);
      const results: Record<string, unknown> = {};
      for (const c of companies ?? []) {
        try {
          results[c.company_code] = await backupCompany(c);
        } catch (e) {
          console.error(c.company_code, e);
          results[c.company_code] = { error: String(e) };
        }
      }
      return reply({ ok: true, results });
    }

    // An admin tapping "Email backup"
    const auth = req.headers.get("Authorization") ?? "";
    const asUser: SupabaseClient = createClient(URL_, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: auth } },
    });
    const { data: isAdmin } = await asUser.rpc("is_admin");
    const { data: companyCode } = await asUser.rpc("my_company");
    if (isAdmin !== true || !companyCode) return reply({ error: "Only an admin can email a backup" });
    const { data: company } = await db.from("companies").select(COLS).eq("company_code", companyCode).maybeSingle();
    if (!company) return reply({ error: "Business not found" });
    if (!company.business_email) {
      return reply({ error: "Add the business email first (Settings → Business email)." });
    }
    const result = await backupCompany(company);
    return reply({ ok: true, ...result });
  } catch (e) {
    console.error(e);
    return reply({ error: "The backup email could not be sent. Check the business email and the SMTP secrets, then try again." });
  }
});
