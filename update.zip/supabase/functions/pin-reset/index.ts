// Chakka Saarthi — pin-reset
// "Forgot Login PIN" for admins: checks User ID + mobile, emails a 6-digit code
// to the admin's saved email, then lets the admin set a new Login PIN with that code.
// Needs two secrets in Supabase (Edge Functions → Secrets):
//   SMTP_USER = the Gmail address that sends the codes
//   SMTP_PASS = that Gmail account's 16-letter App Password
// Optional: SMTP_HOST (default smtp.gmail.com), SMTP_PORT (default 465)
import { createClient } from "jsr:@supabase/supabase-js@2";
import nodemailer from "npm:nodemailer@6.9.16";

const CODE_MINUTES = 10;
const MAX_ATTEMPTS = 5;
const RESEND_SECONDS = 60;

const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

function reply(body: Record<string, unknown>) {
  return new Response(JSON.stringify(body), { headers: { "Content-Type": "application/json" } });
}

async function sha256(text: string): Promise<string> {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

function maskEmail(email: string): string {
  const [name, domain] = email.split("@");
  const shown = name.length <= 2 ? name[0] : name.slice(0, 2);
  return `${shown}${"*".repeat(Math.max(3, name.length - shown.length))}@${domain}`;
}

async function findAdmin(userId: string, mobile: string) {
  const { data } = await db.from("users")
    .select("user_id, full_name, email, role, is_active")
    .eq("mobile", mobile.trim())
    .eq("role", "admin")
    .eq("is_active", true);
  return (data ?? []).find((u) => u.user_id.toUpperCase() === userId.trim().toUpperCase()) ?? null;
}

Deno.serve(async (req) => {
  try {
    const { action, user_id, mobile, code, new_pin_hash } = await req.json();
    if (!user_id || !mobile) return reply({ error: "Enter your User ID and mobile number" });

    const admin = await findAdmin(String(user_id), String(mobile));
    if (!admin) {
      return reply({ error: "User ID and mobile number do not match an admin. Drivers: ask your admin to reset your Login PIN." });
    }

    if (action === "send") {
      if (!admin.email) {
        return reply({ error: "No email is saved for this admin. Ask another admin to add it in Settings → Manage Admins." });
      }
      const { data: last } = await db.from("pin_reset_codes").select("sent_at").eq("user_id", admin.user_id).maybeSingle();
      if (last && Date.now() - new Date(last.sent_at).getTime() < RESEND_SECONDS * 1000) {
        return reply({ error: "A code was just sent. Please wait a minute before asking again." });
      }
      const otp = String(crypto.getRandomValues(new Uint32Array(1))[0] % 1000000).padStart(6, "0");
      await db.from("pin_reset_codes").upsert({
        user_id: admin.user_id,
        code_hash: await sha256(`${admin.user_id}:${otp}`),
        expires_at: new Date(Date.now() + CODE_MINUTES * 60000).toISOString(),
        attempts: 0,
        sent_at: new Date().toISOString(),
      });

      const smtpUser = Deno.env.get("SMTP_USER")!;
      const transport = nodemailer.createTransport({
        host: Deno.env.get("SMTP_HOST") ?? "smtp.gmail.com",
        port: Number(Deno.env.get("SMTP_PORT") ?? 465),
        secure: true,
        auth: { user: smtpUser, pass: Deno.env.get("SMTP_PASS")! },
      });
      await transport.sendMail({
        from: `Chakka Saarthi <${smtpUser}>`,
        to: admin.email,
        subject: `Chakka Saarthi Login PIN code: ${otp}`,
        text: `Hello ${admin.full_name},\n\nYour code to reset your Chakka Saarthi Login PIN is ${otp}.\n` +
          `It is valid for ${CODE_MINUTES} minutes. If you did not ask for this, ignore this email.`,
      });
      return reply({ ok: true, sent_to: maskEmail(admin.email) });
    }

    if (action === "verify") {
      if (!/^[0-9]{6}$/.test(String(code ?? ""))) return reply({ error: "Enter the 6-digit code from the email" });
      if (!/^[a-f0-9]{64}$/.test(String(new_pin_hash ?? ""))) return reply({ error: "Invalid new Login PIN" });

      const { data: row } = await db.from("pin_reset_codes").select("*").eq("user_id", admin.user_id).maybeSingle();
      if (!row || new Date(row.expires_at).getTime() < Date.now()) {
        return reply({ error: "Code expired. Tap 'Send code' again." });
      }
      if (row.attempts >= MAX_ATTEMPTS) {
        return reply({ error: "Too many wrong codes. Tap 'Send code' again." });
      }
      if (row.code_hash !== await sha256(`${admin.user_id}:${code}`)) {
        await db.from("pin_reset_codes").update({ attempts: row.attempts + 1 }).eq("user_id", admin.user_id);
        return reply({ error: `Wrong code. ${MAX_ATTEMPTS - row.attempts - 1} tries left.` });
      }

      await db.from("users").update({ mpin_hash: new_pin_hash, is_first_login: false }).eq("user_id", admin.user_id);
      await db.from("pin_reset_codes").delete().eq("user_id", admin.user_id);
      // Log this admin out of every phone; they log in again with the new Login PIN
      await db.from("app_sessions").delete().eq("user_id", admin.user_id);
      return reply({ ok: true });
    }

    return reply({ error: "Unknown request" });
  } catch (e) {
    console.error(e);
    return reply({ error: "Could not complete the request. Please try again." });
  }
});
