// Chakka Saarthi — send-push
// Sends one saved notification to the target person's phone through Firebase,
// so it arrives even when the app is closed.
// Needs one secret in Supabase: FCM_SERVICE_ACCOUNT = the Firebase service-account JSON.
import { createClient } from "jsr:@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

type ServiceAccount = { project_id: string; client_email: string; private_key: string };

let cachedToken: { value: string; expires: number } | null = null;

function b64url(data: ArrayBuffer | string): string {
  const bytes = typeof data === "string" ? new TextEncoder().encode(data) : new Uint8Array(data);
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

async function googleAccessToken(sa: ServiceAccount): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  if (cachedToken && cachedToken.expires > now + 60) return cachedToken.value;

  const header = b64url(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const claims = b64url(JSON.stringify({
    iss: sa.client_email,
    scope: "https://www.googleapis.com/auth/firebase.messaging",
    aud: "https://oauth2.googleapis.com/token",
    iat: now,
    exp: now + 3600,
  }));
  const pem = sa.private_key.replace(/-----[^-]+-----/g, "").replace(/\s+/g, "");
  const der = Uint8Array.from(atob(pem), (c) => c.charCodeAt(0));
  const key = await crypto.subtle.importKey(
    "pkcs8", der, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"],
  );
  const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(`${header}.${claims}`));
  const jwt = `${header}.${claims}.${b64url(sig)}`;

  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=${jwt}`,
  });
  const json = await res.json();
  if (!res.ok) throw new Error(`Google token error: ${JSON.stringify(json)}`);
  cachedToken = { value: json.access_token, expires: now + (json.expires_in ?? 3600) };
  return cachedToken.value;
}

function reply(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const { id } = await req.json();
    if (!id) return reply({ error: "missing id" }, 400);

    const url = Deno.env.get("SUPABASE_URL")!;
    // 1) Read the notification AS THE CALLER: database rules only allow this
    //    if the caller is logged in to the same company.
    const asCaller = createClient(url, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } },
    });
    const { data: n, error } = await asCaller
      .from("notifications").select("id, target_user_id, title, message, ticket_id").eq("id", id).maybeSingle();
    if (error || !n) return reply({ error: "not allowed" }, 403);

    // 2) Look up the target's phone address (hidden from phones, so use the server key)
    const admin = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: target } = await admin.from("users").select("fcm_token").eq("user_id", n.target_user_id).maybeSingle();
    if (!target?.fcm_token) return reply({ sent: false, reason: "no phone registered" });

    const sa: ServiceAccount = JSON.parse(Deno.env.get("FCM_SERVICE_ACCOUNT") ?? "{}");
    if (!sa.private_key) return reply({ error: "FCM_SERVICE_ACCOUNT secret missing" }, 500);

    const res = await fetch(`https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${await googleAccessToken(sa)}` },
      body: JSON.stringify({
        message: {
          token: target.fcm_token,
          notification: { title: n.title, body: n.message },
          data: { notification_id: String(n.id), ticket_id: n.ticket_id ?? "" },
          android: { priority: "HIGH", notification: { channel_id: "fleet_channel", sound: "default" } },
        },
      }),
    });

    if (!res.ok) {
      const err = await res.text();
      // Phone uninstalled the app or token expired: forget it
      if (res.status === 404 || err.includes("UNREGISTERED")) {
        await admin.from("users").update({ fcm_token: null }).eq("user_id", n.target_user_id);
      }
      return reply({ sent: false, error: err }, 200);
    }
    return reply({ sent: true });
  } catch (e) {
    return reply({ error: String(e) }, 500);
  }
});
